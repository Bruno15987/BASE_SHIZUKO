
module.exports = {
menus: menus = require("./menu.js")
}