

const menu = (prefix, sender, NickDono, NomeBot, data, hora, NumberDono, version) => {
	
return `╭━━ ❄️ ☃️ 𝐈𝐍𝐅𝐎 ☃️ ❄️ ━━╮
┃
┃ 𝐁𝐨𝐭: ${NomeBot}
┃ 𝐕𝐞𝐫𝐬𝐚̃𝐨: ${version}
┃ 𝐔𝐬𝐮𝐚́𝐫𝐢𝐨: @${sender?.split("@")[0]}
┃ 𝐃𝐚𝐭𝐚: ${data}
┃ 𝐇𝐨𝐫𝐚: ${hora}
┃ 𝐏𝐫𝐞𝐟𝐢𝐱𝐨: ${prefix}
┃ 𝐃𝐨𝐧𝐨: ${NickDono}
┃ 𝐂𝐨𝐧𝐭𝐚𝐭𝐨: ${NumberDono}
┃
╰━━━━━━━━━━━━━━━━━━╯

╭── 𝐀𝐃𝐌𝐈𝐍𝐈𝐒𝐓𝐑𝐀𝐂̧𝐀̃𝐎 ──╮
│
│ 𝐌𝐨𝐝𝐞𝐫𝐚𝐜̧𝐚̃𝐨:
│ ☆ۣۜۜ͜͡   - ${prefix}ban
│ ☆ۣۜۜ͜͡   - ${prefix}banir
│ ☆ۣۜۜ͜͡   - ${prefix}kick
│ ☆ۣۜۜ͜͡   - ${prefix}d
│ ☆ۣۜۜ͜͡   - ${prefix}del
│ ☆ۣۜۜ͜͡   - ${prefix}apagar
│ ☆ۣۜۜ͜͡   - ${prefix}avadakedavra
│ ☆ۣۜۜ͜͡   - ${prefix}rebaixar
│ ☆ۣۜۜ͜͡   - ${prefix}promover
│ ☆ۣۜۜ͜͡   - ${prefix}so_adm
│ ☆ۣۜۜ͜͡   - ${prefix}linkgp
│ ☆ۣۜۜ͜͡   - ${prefix}check
│
│ 𝐒𝐞𝐠𝐮𝐫𝐚𝐧𝐜̧𝐚:
│ ☆ۣۜۜ͜͡   - ${prefix}antilink
│ ☆ۣۜۜ͜͡   - ${prefix}antilinkhard
│ ☆ۣۜۜ͜͡   - ${prefix}ativar
│ ☆ۣۜۜ͜͡   - ${prefix}desativar
│ ☆ۣۜۜ͜͡   - ${prefix}bangp
│ ☆ۣۜۜ͜͡   - ${prefix}unbangp
│
╰━━━━━━━━━━━━━━━━╯

╭── 𝐁𝐎𝐀𝐒-𝐕𝐈𝐍𝐃𝐀𝐒 ──╮
│
│ ☆ۣۜۜ͜͡   - ${prefix}bemvindo
│ ☆ۣۜۜ͜͡   - ${prefix}bemvindo2
│ ☆ۣۜۜ͜͡   - ${prefix}welcome
│ ☆ۣۜۜ͜͡   - ${prefix}welcome2
│ ☆ۣۜۜ͜͡   - ${prefix}legendabv
│ ☆ۣۜۜ͜͡   - ${prefix}legendabv2
│ ☆ۣۜۜ͜͡   - ${prefix}legendasaiu
│ ☆ۣۜۜ͜͡   - ${prefix}legendasaiu2
│
╰━━━━━━━━━━━━━━━━╯

╭── 𝐅𝐈𝐆𝐔𝐑𝐈𝐍𝐇𝐀𝐒 ──╮
│
│ 𝐂𝐫𝐢𝐚𝐜̧𝐚̃𝐨:
│ ☆ۣۜۜ͜͡   - ${prefix}s
│ ☆ۣۜۜ͜͡   - ${prefix}st
│ ☆ۣۜۜ͜͡   - ${prefix}stk
│ ☆ۣۜۜ͜͡   - ${prefix}sticker
│ ☆ۣۜۜ͜͡   - ${prefix}toimg
│
│ 𝐏𝐚𝐜𝐨𝐭𝐞𝐬:
│ ☆ۣۜۜ͜͡   - ${prefix}figurinhas
│ ☆ۣۜۜ͜͡   - ${prefix}figuale
│ ☆ۣۜۜ͜͡   - ${prefix}figu_raiva
│ ☆ۣۜۜ͜͡   - ${prefix}figu_roblox
│ ☆ۣۜۜ͜͡   - ${prefix}figu_engracada
│ ☆ۣۜۜ͜͡   - ${prefix}figu_memes
│ ☆ۣۜۜ͜͡   - ${prefix}figu_anime
│ ☆ۣۜۜ͜͡   - ${prefix}figu_coreana
│ ☆ۣۜۜ͜͡   - ${prefix}figu_bebe
│ ☆ۣۜۜ͜͡   - ${prefix}figu_desenho
│ ☆ۣۜۜ͜͡   - ${prefix}figu_animais
│ ☆ۣۜۜ͜͡   - ${prefix}figu_flork
│ ☆ۣۜۜ͜͡   - ${prefix}figu_emoji
│
╰━━━━━━━━━━━━━━━━╯
╭── 𝐃𝐎𝐖𝐍𝐋𝐎𝐀𝐃𝐒 ──╮
│
│ 𝐏𝐥𝐚𝐲 / 𝐌𝐢́𝐝𝐢𝐚:
│ ☆ۣۜۜ͜͡   - ${prefix}play
│ ☆ۣۜۜ͜͡   - ${prefix}play_video
│ ☆ۣۜۜ͜͡   - ${prefix}pdoc
│
│ 𝐁𝐚𝐢𝐱𝐚𝐫:
│ ☆ۣۜۜ͜͡   - ${prefix}ttkdl
│ ☆ۣۜۜ͜͡   - ${prefix}tiktokdl
│ ☆ۣۜۜ͜͡   - ${prefix}instadl
│ ☆ۣۜۜ͜͡   - ${prefix}ytaudio
│ ☆ۣۜۜ͜͡   - ${prefix}ytvideo
│
╰━━━━━━━━━━━━━━━━╯

╭── 𝐈𝐀 & 𝐃𝐈𝐕𝐄𝐑𝐒𝐀̃𝐎 ──╮
│
│ 𝐈𝐧𝐭𝐞𝐥𝐢𝐠𝐞̂𝐧𝐜𝐢𝐚:
│ ☆ۣۜۜ͜͡   - ${prefix}chatgpt
│ ☆ۣۜۜ͜͡   - ${prefix}gpt
│
│ 𝐔́𝐭𝐞𝐢𝐬 & 𝐉𝐨𝐠𝐨𝐬:
│ ☆ۣۜۜ͜͡   - ${prefix}perfil
│ ☆ۣۜۜ͜͡   - ${prefix}metadinhas
│ ☆ۣۜۜ͜͡   - ${prefix}gerarnick
│ ☆ۣۜۜ͜͡   - ${prefix}fazernick
│ ☆ۣۜۜ͜͡   - ${prefix}totalcases
│ ☆ۣۜۜ͜͡   - ${prefix}ping
│ ☆ۣۜۜ͜͡   - ${prefix}checkme
│ ☆ۣۜۜ͜͡   - ${prefix}ver-vip
│ ☆ۣۜۜ͜͡   - ${prefix}gerarlink
│
╰━━━━━━━━━━━━━━━━╯

╭── 𝐃𝐎𝐍𝐎 & 𝐁𝐎𝐓 ──╮
│
│ 𝐂𝐨𝐧𝐟𝐢𝐠𝐮𝐫𝐚𝐜̧𝐨̃𝐞𝐬:
│ ☆ۣۜۜ͜͡   - ${prefix}dono
│ ☆ۣۜۜ͜͡   - ${prefix}donos
│ ☆ۣۜۜ͜͡   - ${prefix}listadonos
│ ☆ۣۜۜ͜͡   - ${prefix}novo-dono
│ ☆ۣۜۜ͜͡   - ${prefix}dono1 até ${prefix}dono6
│ ☆ۣۜۜ͜͡   - ${prefix}nick-dono
│ ☆ۣۜۜ͜͡   - ${prefix}verificado
│
│ 𝐒𝐲𝐬𝐭𝐞𝐦:
│ ☆ۣۜۜ͜͡   - ${prefix}bot
│ ☆ۣۜۜ͜͡   - ${prefix}nome-bot
│ ☆ۣۜۜ͜͡   - ${prefix}setprefix
│ ☆ۣۜۜ͜͡   - ${prefix}botoff
│ ☆ۣۜۜ͜͡   - ${prefix}boton
│ ☆ۣۜۜ͜͡   - ${prefix}reiniciar
│ ☆ۣۜۜ͜͡   - ${prefix}r
│
│ 𝐕𝐈𝐏:
│ ☆ۣۜۜ͜͡   - ${prefix}addvip (marcar @user)
│ ☆ۣۜۜ͜͡   - ${prefix}delvip (marcar @user)
│
╰━━━━━━━━━━━━━━━━╯

╭── 𝐌𝐄𝐍𝐔𝐒 ──╮
│
│ ☆ۣۜۜ͜͡   - ${prefix}menu
│ ☆ۣۜۜ͜͡   - ${prefix}m
│ ☆ۣۜۜ͜͡   - ${prefix}menu_menu
│ ☆ۣۜۜ͜͡   - ${prefix}menufigurinhas
│ ☆ۣۜۜ͜͡   - ${prefix}menufig
│ ☆ۣۜۜ͜͡   - ${prefix}menuadm
│ ☆ۣۜۜ͜͡   - ${prefix}menudono
│ ☆ۣۜۜ͜͡   - ${prefix}menu18
│ ☆ۣۜۜ͜͡   - ${prefix}menu-ia
│ ☆ۣۜۜ͜͡   - ${prefix}brincadeiras
│
╰━━━━━━━━━━━━╯

╭── 𝐏𝐋𝐀𝐐𝐔𝐈𝐍𝐇𝐀𝐒 ──╮
│
│ ☆ۣۜۜ͜͡   - ${prefix}plaq1
│ ☆ۣۜۜ͜͡   - ${prefix}plaq2
│ ☆ۣۜۜ͜͡   - ${prefix}plaq3
│ ☆ۣۜۜ͜͡   - ${prefix}plaq4
│ ☆ۣۜۜ͜͡   - ${prefix}plaq5
│ ☆ۣۜۜ͜͡   - ${prefix}plaq6
│ ☆ۣۜۜ͜͡   - ${prefix}plaq7
│ ☆ۣۜۜ͜͡   - ${prefix}plaq8
│ ☆ۣۜۜ͜͡   - ${prefix}plaq9
│ ☆ۣۜۜ͜͡   - ${prefix}plaq10
│ ☆ۣۜۜ͜͡   - ${prefix}plaq11
│
╰━━━━━━━━━━━━━━╯

*_Olhe os outros menus para ver todos os comandos disponíveis_*
`;


};
exports.menu = menu;

const menuadm = (prefix, sender) => {
return `╭━━ MENU DE ADMINIS ━━╮
┃
┃ ✦ Olá, @${sender?.split("@")[0]}
┃   Central de Controle e Segurança
┃   Sistema ativo.
┃

╭── 𝐂𝐎𝐍𝐓𝐑𝐎𝐋𝐄 𝐃𝐄 𝐆𝐑𝐔𝐏𝐎 ──╮
┃
┃ ☆ۣۜۜ͜͡   - ${prefix}ativar
┃ ☆ۣۜۜ͜͡   - ${prefix}desativar
┃ ☆ۣۜۜ͜͡   - ${prefix}linkgp
┃ ☆ۣۜۜ͜͡   - ${prefix}antilink (1/0)
┃ ☆ۣۜۜ͜͡   - ${prefix}antilinkhard (1/0)
┃ ☆ۣۜۜ͜͡   - ${prefix}so_adm (1/0)
┃ ☆ۣۜۜ͜͡   - ${prefix}modobrincadeira (1/0)
┃ ☆ۣۜۜ͜͡   - ${prefix}anti-mencao (1/0)
┃ ☆ۣۜۜ͜͡   - ${prefix}grupo (a/f/lock/unlock)
┃ ☆ۣۜۜ͜͡   - ${prefix}rmfotogo
┃ ☆ۣۜۜ͜͡   - ${prefix}fotogp
┃ ☆ۣۜۜ͜͡   - ${prefix}redefinirlink
┃ ☆ۣۜۜ͜͡   - ${prefix}status
┃

╭── 𝐀𝐓𝐈𝐕𝐀𝐂̧𝐎̃𝐄𝐒 𝐃𝐄 𝐌𝐄𝐍𝐒𝐀𝐆𝐄𝐌 ──╮
┃
┃ ☆ۣۜۜ͜͡   - ${prefix}bemvindo (1/0)
┃ ☆ۣۜۜ͜͡   - ${prefix}welcome (1/0)
┃ ☆ۣۜۜ͜͡   - ${prefix}legendabv
┃ ☆ۣۜۜ͜͡   - ${prefix}legendasaiu
┃ ☆ۣۜۜ͜͡   - ${prefix}bemvindo2 (1/0)
┃ ☆ۣۜۜ͜͡   - ${prefix}welcome2 (1/0)
┃ ☆ۣۜۜ͜͡   - ${prefix}legendabv2
┃ ☆ۣۜۜ͜͡   - ${prefix}legendasaiu2
┃

╭── 𝐌𝐎𝐃𝐄𝐑𝐀𝐂̧𝐀̃𝐎 ──╮
┃
┃ ☆ۣۜۜ͜͡   - ${prefix}promover (@)
┃ ☆ۣۜۜ͜͡   - ${prefix}rebaixar (@)
┃ ☆ۣۜۜ͜͡   - ${prefix}ban (@)
┃ ☆ۣۜۜ͜͡   - ${prefix}banir (@)
┃ ☆ۣۜۜ͜͡   - ${prefix}kick (@)
┃ ☆ۣۜۜ͜͡   - ${prefix}avadakedavra (@)
┃ ☆ۣۜۜ͜͡   - ${prefix}check
┃ ☆ۣۜۜ͜͡   - ${prefix}d
┃ ☆ۣۜۜ͜͡   - ${prefix}del
┃ ☆ۣۜۜ͜͡   - ${prefix}apagar
┃
╰━━━━━━━━━━━━━━━━━━╯
`;

};
exports.menuadm = menuadm;


const menuStickers = (prefix, sender) => {
return `╭── 𝐅𝐈𝐆𝐔𝐑𝐈𝐍𝐇𝐀𝐒 ──╮
│
│ 𝐂𝐫𝐢𝐚𝐜̧𝐚̃𝐨:
│ ☆ۣۜۜ͜͡   - ${prefix}s
│ ☆ۣۜۜ͜͡   - ${prefix}st
│ ☆ۣۜۜ͜͡   - ${prefix}stk
│ ☆ۣۜۜ͜͡   - ${prefix}sticker
│ ☆ۣۜۜ͜͡   - ${prefix}toimg
│
│ 𝐏𝐚𝐜𝐨𝐭𝐞𝐬:
│ ☆ۣۜۜ͜͡   - ${prefix}figurinhas
│ ☆ۣۜۜ͜͡   - ${prefix}figuale
│ ☆ۣۜۜ͜͡   - ${prefix}figu_raiva
│ ☆ۣۜۜ͜͡   - ${prefix}figu_roblox
│ ☆ۣۜۜ͜͡   - ${prefix}figu_engracada
│ ☆ۣۜۜ͜͡   - ${prefix}figu_memes
│ ☆ۣۜۜ͜͡   - ${prefix}figu_anime
│ ☆ۣۜۜ͜͡   - ${prefix}figu_coreana
│ ☆ۣۜۜ͜͡   - ${prefix}figu_bebe
│ ☆ۣۜۜ͜͡   - ${prefix}figu_desenho
│ ☆ۣۜۜ͜͡   - ${prefix}figu_animais
│ ☆ۣۜۜ͜͡   - ${prefix}figu_flork
│ ☆ۣۜۜ͜͡   - ${prefix}figu_emoji
│
╰━━━━━━━━━━━━━━━━╯
`;
}

exports.menuStickers = menuStickers;

const menu18 = (prefix, sender) => {
return `╭━━━ 𝐍𝐀𝐓𝐀𝐋 +𝟏𝟖 ━━━╮
┃
┃ 𝐇𝐨 𝐇𝐨 𝐇𝐨, @${sender?.split("@")[0]}...
┃   Parece que você foi travesso(a)
┃   esse ano e caiu na 𝐋𝐢𝐬𝐭𝐚 𝐍𝐞𝐠𝐫𝐚.
┃   
┃   Abra seu presente com
┃   cuidado... está quente.
┃
╭── 𝐏𝐀𝐂𝐎𝐓𝐄 𝐏𝐈𝐂𝐀𝐍𝐓𝐄 ──╮
┃
┃ ☆ۣۜۜ͜͡   - ${prefix}plaq1
┃ ☆ۣۜۜ͜͡   - ${prefix}plaq2
┃ ☆ۣۜۜ͜͡   - ${prefix}plaq3
┃ ☆ۣۜۜ͜͡   - ${prefix}plaq4
┃ ☆ۣۜۜ͜͡   - ${prefix}plaq5
┃ ☆ۣۜۜ͜͡   - ${prefix}plaq6
┃ ☆ۣۜۜ͜͡   - ${prefix}plaq7
┃ ☆ۣۜۜ͜͡   - ${prefix}plaq8
┃ ☆ۣۜۜ͜͡   - ${prefix}plaq9
┃ ☆ۣۜۜ͜͡   - ${prefix}plaq10
┃ ☆ۣۜۜ͜͡   - ${prefix}plaq11
┃
╰━━━━━━━━━━━━━━━━━━╯
`;
};

exports.menu18 = menu18;

const menuDono = (prefix, sender) => {
return `╭━━ 𝐂𝐎𝐍𝐓𝐑𝐎𝐋𝐄 𝐃𝐎 𝐓𝐑𝐄𝐍𝐎́ ━━╮
┃
┃ 𝐇𝐨 𝐇𝐨 𝐇𝐨, @${sender?.split("@")[0]}...
┃   Seja bem-vindo ao Escritório Supremo.
┃   Acesso total aos poderes do Polo Norte.
┃
╭── 𝐂𝐎𝐍𝐅𝐈𝐆𝐔𝐑𝐀𝐂̧𝐎̃𝐄𝐒 𝐃𝐎 𝐁𝐎𝐓 ──╮
┃
┃ ☆ۣۜۜ͜͡   - ${prefix}setprefix
┃ ☆ۣۜۜ͜͡   - ${prefix}nome-bot
┃ ☆ۣۜۜ͜͡   - ${prefix}nick-dono
┃ ☆ۣۜۜ͜͡   - ${prefix}verificado
┃ ☆ۣۜۜ͜͡   - ${prefix}totalcases
┃ ☆ۣۜۜ͜͡   - ${prefix}cases
┃ 
╭── 𝐆𝐄𝐑𝐄𝐍𝐂𝐈𝐀𝐌𝐄𝐍𝐓𝐎 𝐒𝐈𝐒𝐓𝐄𝐌𝐀 ──╮
┃
┃ ☆ۣۜۜ͜͡   - ${prefix}reiniciar
┃ ☆ۣۜۜ͜͡   - ${prefix}r
┃ ☆ۣۜۜ͜͡   - ${prefix}bot
┃ ☆ۣۜۜ͜͡   - ${prefix}botoff
┃ ☆ۣۜۜ͜͡   - ${prefix}so_dono
┃ ☆ۣۜۜ͜͡   - ${prefix}boton
┃ ☆ۣۜۜ͜͡   - ${prefix}bangp
┃ ☆ۣۜۜ͜͡   - ${prefix}unbangp
┃ ☆ۣۜۜ͜͡   - ${prefix}avadakedavra
┃ ☆ۣۜۜ͜͡   - ${prefix}visumsg
┃ ☆ۣۜۜ͜͡   - ${prefix}visualizarmsg
┃
╭── 𝐆𝐄𝐑𝐄𝐍𝐂𝐈𝐀𝐌𝐄𝐍𝐓𝐎 𝐃𝐄 𝐃𝐎𝐍𝐎𝐒 ──╮
┃
┃ ☆ۣۜۜ͜͡   - ${prefix}dono
┃ ☆ۣۜۜ͜͡   - ${prefix}donos
┃ ☆ۣۜۜ͜͡   - ${prefix}listadonos
┃ ☆ۣۜۜ͜͡   - ${prefix}novo-dono
┃ ☆ۣۜۜ͜͡   - ${prefix}fotomenu
┃ ☆ۣۜۜ͜͡   - ${prefix}dono1 até ${prefix}dono6
┃ ☆ۣۜۜ͜͡   - ${prefix}serperfil
┃ ☆ۣۜۜ͜͡   - ${prefix}rm-fotobot 
┃ ☆ۣۜۜ͜͡   - ${prefix}rmfotobot
┃
╭── 𝐎𝐔𝐓𝐑𝐎𝐒 ──╮
┃
┃ ☆ۣۜۜ͜͡   - ${prefix}addvip (marcar @user)
┃ ☆ۣۜۜ͜͡   - ${prefix}delvip (marcar @user)
┃
╭── 𝐌𝐄𝐍𝐔𝐒 𝐄𝐒𝐏𝐄𝐂𝐈𝐀𝐈𝐒 ──╮
┃
┃ ☆ۣۜۜ͜͡   - ${prefix}menudono
┃
╰━━━━━━━━━━━━━━━━━━━━╯
`;

};
exports.menuDono = menuDono;

const menuDown = (prefix, sender) => {
return `╭━━ 𝐄𝐍𝐓𝐑𝐄𝐆𝐀 𝐃𝐎 𝐓𝐑𝐄𝐍𝐎́ ━━╮
│
╭── 𝐏𝐑𝐄𝐒𝐄𝐍𝐓𝐄𝐒 𝐀𝐔𝐃𝐈𝐎𝐕𝐈𝐒𝐔𝐀𝐈𝐒 ──╮
│
│ ☆ۣۜۜ͜͡   - ${prefix}play
│ ☆ۣۜۜ͜͡   - ${prefix}play_video
│ ☆ۣۜۜ͜͡   - ${prefix}pdoc
│
╭── 𝐀𝐋𝐈𝐙𝐀𝐍𝐃𝐎 𝐀 𝐄𝐍𝐓𝐑𝐄𝐆𝐀 ──╮
│
│ ☆ۣۜۜ͜͡   - ${prefix}ttkdl
│ ☆ۣۜۜ͜͡   - ${prefix}tiktokdl
│ ☆ۣۜۜ͜͡   - ${prefix}instadl
│ ☆ۣۜۜ͜͡   - ${prefix}ytaudio
│ ☆ۣۜۜ͜͡   - ${prefix}ytvideo
╰━━━━━━━━━━━━━━━━━━╯
`;
};
exports.menuDown = menuDown;

const menuBn = (prefix, sender) => {
return `
╭──  *MENU BRINCADEIRAS* ──╮
│
│ ☆ۣۜۜ͜͡   - ${prefix}abraco
│ ☆ۣۜۜ͜͡   - ${prefix}abracar
│ ☆ۣۜۜ͜͡   - ${prefix}beijo
│ ☆ۣۜۜ͜͡   - ${prefix}beijar
╰━━━━━━━━━━━━━━━━━━╯

`;
};

exports.menuBn = menuBn;

const menuIa = (prefix, sender) => {
return `
╭── *MENU IAS* ──╮
│
│ ☆ۣۜۜ͜͡   - ${prefix}gpt
│ ☆ۣۜۜ͜͡   - ${prefix}chatgpt 
│ ☆ۣۜۜ͜͡   - ${prefix}perplexity 
│ ☆ۣۜۜ͜͡   - ${prefix}pxt
╰━━━━━━━━━━━━━━━━━━╯
`;
};

exports.menuIa = menuIa;

const menuVip = (prefix, sender) => {
return `
╭── *MENU IAS* ──╮
│
│ ☆ۣۜۜ͜͡   - ${prefix}ver-vip 
│ ☆ۣۜۜ͜͡   - ${prefix}gethtml
╰━━━━━━━━━━━━━━╯`;
};
exports.menuVip = menuVip;



/* 
pra adicionar mais menus e etcc...

segue a lógica!!

const menu2 = (prefix, sender) => {
	return `txt
	k
	k
	k
	`;
	}
	exports.menu2 = menu2;
	
na index:

conn.sendMessage(from, { image: FotoMenu, caption: menus.menu(prefix, sender), mentions: [sender]})

*/

